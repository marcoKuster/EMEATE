({
    doInit : function(component, event, helper) {
        helper.getProductTagFields(component);
        
    }
    
})