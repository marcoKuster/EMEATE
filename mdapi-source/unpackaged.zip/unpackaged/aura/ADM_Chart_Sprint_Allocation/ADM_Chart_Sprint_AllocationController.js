({
	getAllocationChartData : function(component, event, helper) {
		helper.getAllocationChartData(component, event, helper);
	}
})