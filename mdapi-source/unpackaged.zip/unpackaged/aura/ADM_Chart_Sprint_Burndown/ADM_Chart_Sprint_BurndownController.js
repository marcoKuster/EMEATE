({
	handleSprintDataEvent : function(component, event, helper) {
		helper.getSprintBurndownChart(component, event, helper);
    }
})