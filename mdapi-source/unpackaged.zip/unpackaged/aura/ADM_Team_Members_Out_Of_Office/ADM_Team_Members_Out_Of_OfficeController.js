({
    doInit : function(component, event, helper) {
        helper.outOfOfficeListOfTeamMembers(component);
    }
    
})