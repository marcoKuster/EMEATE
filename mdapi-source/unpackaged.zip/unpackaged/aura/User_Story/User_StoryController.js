({
	handleRecordUpdated : function(component, event, helper) {
		helper.recordUpdated(component, event, helper);
	}
})